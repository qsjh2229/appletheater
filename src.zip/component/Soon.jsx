import soon1 from "../image/soon/soon1.jpg";
import soon2 from "../image/soon/soon2.jpg";
import soon3 from "../image/soon/soon3.jpg";
import soon4 from "../image/soon/soon4.jpg";
import soon5 from "../image/soon/soon5.jpg";
import soon6 from "../image/soon/soon6.jpg";
import soon7 from "../image/soon/soon7.jpg";
import soon8 from "../image/soon/soon8.jpg";

const Soon = [
  { img: soon1, title: '컬러 퍼블랙' },
  { img: soon2, title: '풍재기시' },
  { img: soon3, title: 'cobweb' },
  { img: soon4, title: '남은 인생 10년' },
  { img: soon5, title: '가가린' },
  { img: soon6, title: '대외비' },
  { img: soon7, title: '소울메이트' },
  { img: soon8, title: '렌필드' },
];

export default Soon;
