import eventing1 from "../image/event/event1.jpg";
import eventing2 from "../image/event/event2.jpg";
import eventing3 from "../image/event/event3.jpg";
import eventing4 from "../image/event/event4.jpg";
import eventing5 from "../image/event/event5.jpeg";
import eventing6 from "../image/event/event6.jpg";


const Eventpa = [
  { img: eventing1, title: 'rhkdrh ' },
  { img: eventing2, title: '풍재기시' },
  { img: eventing3, title: 'cobweb' },
  { img: eventing4, title: '남은 인생 10년' },
  { img: eventing5, title: '가가린' },
  { img: eventing6, title: '대외비' },

];

export default Eventpa;
